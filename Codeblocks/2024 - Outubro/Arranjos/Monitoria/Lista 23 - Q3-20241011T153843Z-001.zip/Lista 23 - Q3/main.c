#include <stdio.h>
#include <stdlib.h>

// 1 - Construa uma fun��o que receba um arranjo de reais e o seu tamanho. A fun��o dever� trocar o primeiro elemento do arranjo com o �ltimo.
// 2 - Construa uma fun��o que receba um arranjo de reais e o seu tamanho. A fun��o dever� trocar dois elementos de lugar. As duas posi��es dever�o tamb�m ser parametrizadas..

void apresentacao()
{
    printf("\nBem vindo ao programa!\n");
}

void func(float vet[])
{
    float digito = 0;

    for(int i=0; i < 10; i++)
    {
        printf("\nDigite o %i.o valor: \n", i+1);
        scanf("%f", &vet[i]);
    }
}

void maiorValor(float vet[])
{
    float aux = 0;
    float maior = 0;

    for(int i=0; i < 10; i++)
    {
        if(vet[i] > maior)
        {
            maior = vet[i];
        }
    }

    aux = vet[9];
    vet[9] = maior;
    maior = aux;
}


void escreveValor(float vet[])
{
    printf("\n");
    for(int i=0; i < 10; i++)
        printf("%i.a posicao = %.2f, \n", i+1, vet[i]);

    printf("\n\nOs valores alterados foram as posicoes: [1 com 10] e [2 com 9]\n");
}

int main()
{
    apresentacao();

    float real[10];

    func(real);

    maiorValor(real);

    escreveValor(real);



    return 0;
}
